# Welcome to Introduction to Node.js!

Instructor: Eric Greene

Schedule: Monday through Wednesday, 9am to 4:30pm

Breaks:
	Morning: 10:30am to 10:45am
	Lunch: Noon to 1pm
	Afternoon: 2:45pm to 3pm

Class Introductions...
